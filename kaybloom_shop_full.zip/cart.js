function getCart(){
  return JSON.parse(localStorage.getItem('cart')||"[]");
}
function saveCart(c){ localStorage.setItem('cart',JSON.stringify(c)); }

function addToCart(name, price){
  const cart = getCart();
  cart.push({name,price});
  saveCart(cart);
  alert("Added to cart!");
}

function clearCart(){
  localStorage.removeItem('cart');
  renderCart();
}

function renderCart(){
  const cart = getCart();
  const container = document.getElementById('cart-items');
  const totalBox = document.getElementById('cart-total');
  let html = "";
  let total = 0;

  cart.forEach((item, i)=>{
    total += item.price;
    html += `<div class="cart-row">
               <p>${item.name}</p>
               <p>₦${item.price}</p>
             </div>`;
  });

  container.innerHTML = html || "<p>Your cart is empty.</p>";
  totalBox.textContent = cart.length ? "Total: ₦" + total : "";
}

if(document.getElementById('cart-items')){
  renderCart();
}
